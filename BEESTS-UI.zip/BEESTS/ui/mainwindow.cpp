#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <iostream>
#include <fstream>

#include <QString>
#include <QFileDialog>
#include <QGridLayout>
#include <QLayout>
#include <QDebug>
#include <QThread>

#include <QWebFrame>

#include <QStandardPaths>


using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    m_dataSet = NULL;
    m_rScriptRunning = false;

    ui->setupUi(this);

	m_process = new QProcess(this);
    connect(m_process, SIGNAL(readyReadStandardOutput()), this, SLOT(subProcessStandardOutput()));
	connect(m_process, SIGNAL(readyReadStandardError()), this, SLOT(subProcessStandardError()));
	connect(m_process, SIGNAL(error(QProcess::ProcessError)), this, SLOT(subProcessError()));
    connect(m_process, SIGNAL(finished(int,QProcess::ExitStatus)), this, SLOT(subProcessFinished(int,QProcess::ExitStatus)));
	connect(m_process, SIGNAL(started()), this, SLOT(subProcessStarted()));

	m_messageBox = new QMessageBox(
				QMessageBox::Information,
				QString("Warning"),
				QString("The opened file is not appropriately formated for analysis. A comma separated file with 4 or 5 columns and appropriate headings is required."),
				QMessageBox::Ok,
				this);
	m_messageBox->addButton(QString("More info ..."), QMessageBox::HelpRole);
    connect(m_messageBox, SIGNAL(buttonClicked(QAbstractButton*)), this, SLOT(onDialogResponse(QAbstractButton*)));

	m_programDir = QFileInfo( QCoreApplication::applicationFilePath() ).absoluteDir();

#ifdef __APPLE__
	m_pythonExe = m_programDir.absoluteFilePath("Python-2.7.3/python.exe");
	m_rScriptExe = m_programDir.absoluteFilePath("R-3.0.0/bin/Rscript");
#else
	m_pythonExe = m_programDir.absoluteFilePath("Python-2.7.3/python.exe");
	m_rScriptExe = m_programDir.absoluteFilePath("R-2.15.3/App/R-Portable/bin/Rscript.exe");
#endif

	qDebug() << m_pythonExe;

	QFile help(m_programDir.absoluteFilePath("info.html"));
	help.open(QFile::ReadOnly);
	QString helpContent(help.readAll());
    ui->webView->setHtml(helpContent);

	m_tableModel = new DataSetTableModel();

	ui->tableView->setModel(m_tableModel);

	ui->tabWidget->setCurrentIndex(1);

#ifdef __APPLE__

	ui->tabWidget->setStyleSheet(QString("QTabWidget::pane { border: none; }"));

	int left, top, right, bottom;
	ui->topLayout->getContentsMargins(&left, &top, &right, &bottom);
	top = 20;
	ui->topLayout->setContentsMargins(left, top, right, bottom);

#endif

	QIntValidator *validator = new QIntValidator(1, 10000000, this);

	ui->textFieldSamples->setValidator(validator);
	ui->textFieldBurnIn->setValidator(validator);
	ui->textFieldNumberOfChains->setValidator(validator);
	ui->textFieldThinning->setValidator(validator);
    ui->textFieldPosteriorPredictorSamples->setValidator(validator);

	ui->textFieldSamples->selectAll();

    int totalCores = QThread::idealThreadCount();
    int cores = std::max(1, totalCores - 1);

    ui->textFieldCPUCores->setText(QString::number(cores));

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::openSelectedHandler() {

	m_dataFile = QFileDialog::getOpenFileName(this,
		 tr("Open CSV File"), QStandardPaths::standardLocations(QStandardPaths::DocumentsLocation).at(0), tr("CSV Files (*.csv)"));

	if ( ! m_dataFile.isNull()) {

		ifstream is;
		is.open(m_dataFile.toStdString().c_str(), ios::in);

		DataSet *oldDataSet = m_dataSet;

		m_dataSet = new DataSet(is);
		m_tableModel->setDataSet(m_dataSet);

        if (oldDataSet != NULL)
            delete oldDataSet;

		checkDataSet();

		is.close();
	}
}

void MainWindow::exitSelectedHandler() {

	QApplication::exit(0);
}

void MainWindow::runSelectedHandler()
{
	if (m_process->state() != QProcess::Running)
	{
		QStringList args = QStringList();
		args << "-u"
				<< m_programDir.absoluteFilePath("stopsignal/run.py")
				<< ui->textFieldSamples->text()
				<< ui->textFieldBurnIn->text()
				<< ui->textFieldNumberOfChains->text()
				<< ui->textFieldThinning->text()
                << ui->comboBoxEstimatesForSubjectsOrGroups->currentText()
                << (ui->checkBoxSummaryStatistics->isChecked() ? "1" : "0")
                << (ui->checkBoxPosteriorDistributions->isChecked() ? "1" : "0")
                << (ui->checkBoxMCMCChains->isChecked() ? "1" : "0")
                << (ui->checkBoxDeviance->isChecked() ? "1" : "0")
				<< (ui->checkBoxPosteriorPredictors->isChecked() ? "1" : "0")
                << ui->textFieldPosteriorPredictorSamples->text()
                << ui->textFieldCPUCores->text()
				<< m_dataFile;

        QProcessEnvironment env = QProcessEnvironment::systemEnvironment();
        env.insert("PATH", m_programDir.absolutePath());

        m_process->setWorkingDirectory(m_programDir.absolutePath());
        m_process->setEnvironment(env.toStringList());
		m_process->start(m_pythonExe, args, QProcess::ReadOnly);
	}
	else
	{
		m_process->kill();

		if (!m_rScriptRunning && ui->textFieldCPUCores->text() != "1")
		{
			QString message("Unable to terminate parallel processes: Processes may still be running, you can 'kill' these in the Task Manager");
			message.prepend("<span style='color: red'>");
			message.append("</span>");

			ui->programOutput->moveCursor(QTextCursor::End);
			ui->programOutput->insertHtml(message);
		}

	}
}

void MainWindow::clearSelectedHandler()
{
	ui->programOutput->clear();
}

void MainWindow::onDialogResponse(QAbstractButton *button)
{
	QMessageBox::ButtonRole role = m_messageBox->buttonRole(button);

	if (role == QMessageBox::HelpRole)
    {
        ui->webView->page()->currentFrame()->scrollToAnchor(QString("file-format"));
		ui->tabWidget->setCurrentIndex(2);
	}
}

void MainWindow::subProcessStandardOutput()
{
	QString output(m_process->readAllStandardOutput());
    output.replace("\n", "<br>");
    output.replace("\r", "<br>");

    ui->programOutput->moveCursor(QTextCursor::End);
    ui->programOutput->insertHtml(output);
}

void MainWindow::subProcessStandardError()
{
	QString output(m_process->readAllStandardError());

    output.prepend("<span style='color: red'>");
    output.append("</span>");
    output.replace("\n", "<br>");
    output.replace("\r", "<br>");

    ui->programOutput->moveCursor(QTextCursor::End);
    ui->programOutput->insertHtml(output);
}

void MainWindow::subProcessStarted()
{
    //ui->buttonRun->setText(QString("Stop"));
    ui->buttonRun->setEnabled(false);
}

void MainWindow::subProcessError()
{
    if (m_process->error() == QProcess::FailedToStart)
		ui->programOutput->append(QString("<span style='color: red'>subprocess failed to start</span>"));
	else
        ui->programOutput->append(QString("<span style='color: red'>process stopped (%1)</span>").arg(m_process->error()));
}

void MainWindow::subProcessFinished(int exitCode, QProcess::ExitStatus exitStatus)
{
    if (exitStatus == QProcess::NormalExit && exitCode == 0)
    {
        if ( ! m_rScriptRunning)
        {
            QStringList args = QStringList();
            args << m_programDir.absoluteFilePath("stopsignal/run.R")
                    << ui->textFieldSamples->text()
                    << ui->textFieldBurnIn->text()
                    << ui->textFieldNumberOfChains->text()
                    << ui->textFieldThinning->text()
                    << ui->comboBoxEstimatesForSubjectsOrGroups->currentText()
                    << (ui->checkBoxSummaryStatistics->isChecked() ? "1" : "0")
                    << (ui->checkBoxPosteriorDistributions->isChecked() ? "1" : "0")
                    << (ui->checkBoxMCMCChains->isChecked() ? "1" : "0")
                    << (ui->checkBoxDeviance->isChecked() ? "1" : "0")
                    << (ui->checkBoxPosteriorPredictors->isChecked() ? "1" : "0")
                    << ui->textFieldPosteriorPredictorSamples->text()
                    << ui->textFieldCPUCores->text()
                    << m_dataFile;

			QProcessEnvironment env = QProcessEnvironment::systemEnvironment();

#ifdef __APPLE__
			env.insert("RHOME", m_programDir.absoluteFilePath("R-3.0.0"));
			env.insert("R_HOME", m_programDir.absoluteFilePath("R-3.0.0"));
			env.insert("R_HOME_DIR", m_programDir.absoluteFilePath("R-3.0.0"));
#endif

			m_process->setWorkingDirectory(m_programDir.absoluteFilePath("stopsignal"));
			m_process->setEnvironment(env.toStringList());
			m_process->start(m_rScriptExe, args, QProcess::ReadOnly);

            m_rScriptRunning = true;
        }
        else
        {
            m_rScriptRunning = false;
            //ui->buttonRun->setText(QString("Run"));
            ui->buttonRun->setEnabled(true);
        }
    }
    else
    {
        m_rScriptRunning = false;
        //ui->buttonRun->setText(QString("Run"));
        ui->buttonRun->setEnabled(true);
    }

}

void MainWindow::checkDataSet()
{

	if (m_dataSet->getColumnCount() == 4
			&& m_dataSet->getColumnHeader(0) == "ss_presented"
			&& m_dataSet->getColumnHeader(1) == "inhibited"
			&& m_dataSet->getColumnHeader(2) == "ssd"
			&& m_dataSet->getColumnHeader(3) == "rt")
	{
		ui->analysisWidgets->setEnabled(true);
		ui->comboBoxEstimatesForSubjectsOrGroups->setCurrentIndex(0);
		ui->comboBoxEstimatesForSubjectsOrGroups->setEnabled(false);
		ui->tabWidget->setCurrentIndex(0);
	}
	else if (m_dataSet->getColumnCount() == 5
			 && m_dataSet->getColumnHeader(0) == "subj_idx"
			 && m_dataSet->getColumnHeader(1) == "ss_presented"
			 && m_dataSet->getColumnHeader(2) == "inhibited"
			 && m_dataSet->getColumnHeader(3) == "ssd"
			 && m_dataSet->getColumnHeader(4) == "rt")
	{
		ui->analysisWidgets->setEnabled(true);
		ui->comboBoxEstimatesForSubjectsOrGroups->setEnabled(true);
		ui->tabWidget->setCurrentIndex(0);
	}
	else
	{
		ui->analysisWidgets->setEnabled(false);
		m_messageBox->show();
	}
}
