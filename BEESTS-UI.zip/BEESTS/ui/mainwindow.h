#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QProcess>
#include <QMessageBox>
#include <QDir>

#include "datasettablemodel.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();


private slots:
    void openSelectedHandler();
	void exitSelectedHandler();
	void runSelectedHandler();
	void clearSelectedHandler();

	void onDialogResponse(QAbstractButton *button);

    void subProcessStandardOutput();
	void subProcessStandardError();
	void subProcessStarted();
	void subProcessError();
    void subProcessFinished(int exitCode, QProcess::ExitStatus exitStatus);
    
private:

    bool m_rScriptRunning;

    DataSet *m_dataSet;
	void checkDataSet();

    Ui::MainWindow *ui;

    QProcess *m_process;

	QDir m_programDir;
	QString m_pythonExe;
    QString m_rScriptExe;

	QString m_dataFile;

	QMessageBox *m_messageBox;

	DataSetTableModel *m_tableModel;
};

#endif // MAINWINDOW_H
